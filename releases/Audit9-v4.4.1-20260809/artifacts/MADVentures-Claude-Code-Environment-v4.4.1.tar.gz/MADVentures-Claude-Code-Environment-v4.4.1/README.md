# MAD Ventures Claude Code Operating Environment v4.4.1

**Release date:** 2026-08-06  
**Owner:** MAD Ventures Holdings / FounderOS  
**Minimum supported Claude Code:** `2.1.223`  
**Official documentation baseline used for this build:** Claude Code `2.1.223` (2026-08-06)  

> **Delivery correction:** Start with `README_FIRST.txt` or `OPEN_ME_FIRST.md`. On macOS, Finder hides the canonical `project/.claude` payload. V4.4.1 adds a visible inspection mirror and a guided `INSTALL_MAC.command` launcher.

**Recommended runtime:** newest Claude Code release permitted by the user’s account and organization

This package turns Claude Code into a governed engineering operating environment for MAD Ventures and FounderOS. It combines repository doctrine, role-routed subagents, reusable skills, deterministic hooks, model/effort routing, a subscription-first Python control plane, cloud-session assets, checkpoint/context guidance, a portable plugin, conservative installers, and release validation.

> **Operating doctrine:** cheap fan-out, expensive judgment; evidence before assertion; one accountable builder; independent review stays edit-less; Founder authorization remains Founder-only.

**Begin with [`START_HERE.md`](START_HERE.md)** for the complete install-to-first-build operating sequence.

## What v4.4 adds

V4.4 preserves the complete v4.3 Claude Code environment and adds a **subscription-first Python
engineering control plane** rather than replacing the CLI, agents, skills, or hooks:

- Python orchestrates native `claude -p` under the authenticated Claude subscription login by default;
- the default Python installation has no third-party dependency and does not require an API key;
- subscription mode fails closed when an API key, provider route, gateway, custom base URL, or
  API-key helper could override the subscription lane;
- separate API billing requires `--billing-mode api --allow-api-billing` plus a positive
  `--max-budget-usd` in the same invocation;
- the optional Agent SDK is installed only with `--with-sdk` / `-WithSdk` and is restricted by this
  package to the explicit API-billed lane;
- eleven governed routes cover planning, approved building, deterministic verification, Tier-1/Tier-2 exact-SHA
  Tier-2 review, release readiness, repository/security/UI audits, and bounded repair;
- read-only routes may use tightly registered exploration/review subagents; mutation routes remain
  single-builder;
- every `claude -p` run receives an ephemeral Python-generated `PreToolUse` policy hook, structured
  JSON Schema output, strict empty MCP, route-specific tools, and scope enforcement;
- Founder approval is bound to the exact plan SHA-256, goal, scopes, acceptance criteria, and commands;
- Python executes verification rather than accepting the builder's narrative as proof;
- detached temporary worktrees isolate exact-SHA review and release-readiness assessment;
- redacted, hashed evidence bundles are written under `.claude/evidence/python-control-plane/`;
- the project and portable skill libraries expand from 30 to 31 and scoped rules from 7 to 8.

## Included systems

| System | Full project environment | Portable plugin |
|---|---:|---:|
| Specialized subagents | 20 | 19 |
| Reusable skills | 31 | 31 |
| Executable JavaScript workflows | 0 | 0 |
| Scoped project rules | 8 | — |
| Python-backed hook adapters | 1 | 1 |
| FounderOS repository profiles | 3 | — |
| Settings profiles | 4 | — |
| Model launch profiles | 10 | — |
| Python control-plane routes | 11 | Baseline policy modules only |
| Cloud environment assets | Yes | — |
| macOS/Linux/WSL installers | Yes | Yes |
| Windows PowerShell installers | Yes | Yes |
| Static validation and smoke tests | Yes | Included in package validation |
| SHA-256 manifest | Generated during release validation | Included in main manifest |

The plugin intentionally excludes `neon-reader`. Safe database work requires a separately configured read-only identity plus the full project's agent-scoped Python SQL policy.

## Recommended installation: full project environment

Use this for `FounderOS`, `founder-os-telegram`, `founder-os-console`, and any repository where the strongest governance is required.

### macOS

Recommended: extract `MADVentures-Claude-Code-Environment-v4.4.1.tar.gz`, then right-click `INSTALL_MAC.command` and choose **Open**. The guided installer verifies the package, prompts for the target repository, installs the Python control plane, and opens the resulting `.claude` folder.

Terminal path:

```bash
tar -xzf MADVentures-Claude-Code-Environment-v4.4.1.tar.gz
cd MADVentures-Claude-Code-Environment-v4.4.1
bash scripts/install.sh /absolute/path/to/repository --profile auto --install-python-control-plane
```

### Linux or WSL

```bash
unzip MADVentures-Claude-Code-Environment-v4.4.1.zip
cd MADVentures-Claude-Code-Environment-v4.4.1
bash scripts/install.sh /absolute/path/to/repository --profile auto --install-python-control-plane
```

### Windows PowerShell

```powershell
Expand-Archive .\MADVentures-Claude-Code-Environment-v4.4.1.zip -DestinationPath .
Set-Location .\MADVentures-Claude-Code-Environment-v4.4.1
Set-ExecutionPolicy -Scope Process Bypass
.\INSTALL_WINDOWS.ps1 -ProjectPath 'C:\absolute\path\to\repository'
```

The installer uses one cross-platform Python lifecycle engine. It validates required runtime versions before writes, creates a restorable backup, deterministically merges mandatory enforcement into existing settings, removes retired managed workflow/hook engines during updates, runs installed-copy checks, records managed-file hashes, installs MCP only as an inactive example, and never writes credentials.

Lifecycle commands:

```bash
bash scripts/install.sh install /absolute/path/to/repository --dry-run
bash scripts/install.sh update /absolute/path/to/repository
bash scripts/install.sh status /absolute/path/to/repository --json
bash scripts/install.sh doctor /absolute/path/to/repository --json
bash scripts/install.sh uninstall /absolute/path/to/repository --dry-run
bash scripts/install.sh restore /absolute/path/to/repository --backup /absolute/path/to/repository/.claude-backups/<backup>
```

See [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md).


## Subscription-first Python control plane

The full installer copies transparent Python source into the repository. Use it when a task benefits
from deterministic stage ordering, structured JSON, plan-bound approval, changed-file scope
enforcement, Python-run verification, bounded repair, or exact-SHA isolation.

The default backend is the native Claude Code programmatic interface:

```text
--backend cli
--billing-mode subscription
```

It uses the existing Claude subscription login and does **not** require `ANTHROPIC_API_KEY`.

```bash
claude auth login
./scripts/install-python-control-plane.sh
madclaude auth-check --repo .
madclaude doctor --repo .
madclaude routes --json
```

Repository-local invocation is also supported:

```bash
python3 .claude/control-plane/madclaude.py auth-check --repo .
```

When `ANTHROPIC_API_KEY` or another higher-precedence API/provider credential is active,
subscription mode stops before Claude starts. This prevents a non-interactive `claude -p` run from
silently moving to separately billed Console API usage.

The optional Agent SDK is not needed for subscription use. Install it only for a deliberately
API-billed integration:

```bash
./scripts/install-python-control-plane.sh --with-sdk
```

API billing then still requires `--billing-mode api --allow-api-billing` and a positive
`--max-budget-usd` per invocation. Auth preflight proves the credential lane, not the final invoice,
remaining plan allowance, model-specific entitlement, or whether account-level extra usage is
enabled. Python Fable/ambiguous-model routes add a second gate: Pro or unproven seat classes must use
`--model opus` / `--model sonnet` or explicitly acknowledge possible usage-credit billing with
`--allow-usage-credits`.

See [`docs/AUTHENTICATION_AND_BILLING.md`](docs/AUTHENTICATION_AND_BILLING.md),
[`docs/PYTHON_CONTROL_PLANE.md`](docs/PYTHON_CONTROL_PLANE.md), and
[`examples/PYTHON_CONTROL_PLANE_INVOCATIONS.md`](examples/PYTHON_CONTROL_PLANE_INVOCATIONS.md).

## Optional installation: portable plugin

Use the plugin for namespaced FounderOS tooling across other MAD Ventures repositories.

One-session test:

```bash
claude --plugin-dir ./plugin/madventures-founderos
```

Persistent personal installation:

```bash
./scripts/install-plugin.sh --scope user
```

```powershell
.\scripts\install-plugin.ps1 -Scope user
```

Plugin commands are namespaced:

```text
/madventures-founderos:founder-command
```

Do not install the portable plugin beside the full project package unless duplicate namespaced and unnamespaced tools are intentional. See [`docs/PLUGIN_DEPLOYMENT.md`](docs/PLUGIN_DEPLOYMENT.md).

## First governed session

From the repository root:

```bash
claude update
claude --version
claude doctor
claude --permission-mode plan --model sonnet --effort high
# Optional selective escalation: add --advisor opus
```

Inside Claude Code:

```text
/status
/doctor
/memory
/agents
/skills
/workflows
/hooks
/permissions
/founderos-onboard
/claude-doctor-plus full
```

Complete `.claude/PROJECT_PROFILE.md` before material implementation. It is the repository contract for commands, architecture, protected paths, governing decisions, runtime checks, current objective, and acceptance criteria.

## Choose the smallest reliable surface

| Surface | Best use |
|---|---|
| Main conversation | One tightly coupled interactive task |
| Skill | Reusable procedure whose next step still depends on judgment |
| Subagent | One bounded isolated analysis or implementation assignment |
| Worktree agent | Independent edits that must not collide |
| Python control plane | All repeatable orchestration, deterministic gates, evidence, exact-SHA review, and bounded repair |
| Agent team | A few long-running peers that need shared coordination |
| Goal | Autonomous work with a machine-verifiable end condition |
| Cloud session | Persistent execution on Anthropic-managed infrastructure |
| Remote Control | Steer a local Claude Code session from web/mobile while local files and tools remain on the local machine |

Start with `/founder-command <goal>` when the correct surface is unclear. Use `/cloud-session route <task>` when deciding between cloud, Remote Control, and a local background session. See [`docs/COMMAND_PALETTE.md`](docs/COMMAND_PALETTE.md).

## Model and effort routing

| Work class | Default route |
|---|---|
| Repository exploration and mechanical scans | Haiku, no effort override |
| Feature implementation, tests, ordinary debugging | Sonnet, usually high |
| Demanding diagnosis, performance, deep technical review | Opus, high/xhigh |
| Architecture, adversarial verification, final synthesis, costly autonomy | Fable, high/xhigh/max when available |
| Uncertain routing | Inherit the session model |

**Billing boundary:** Fable inclusion is plan/seat specific. On Pro and standard seats it can use
usage credits from the start even though authentication is through the subscription rather than an
API key. The Python control plane fails closed for that risk unless an included exact model is chosen
or `--allow-usage-credits` is supplied. Native sessions require the same manual `/status` and Usage
settings check.

Shared files use aliases (`haiku`, `sonnet`, `opus`, `fable`, `best`, `inherit`) rather than fragile dated IDs. Availability and alias resolution remain live account/provider facts. The package pins Fable only for planning and judgment routes where silent downgrade would be unsafe; `best-available` is the explicit fallback. `/fast` accelerates a supported Opus route rather than changing to a smaller model. `ultracode` is a session mode for high-reasoning workflow orchestration, not another model tier. The opt-in advisor route runs Sonnet as the primary model with Opus available at selected decision points; an advisor shares the session context, is not independent review, and Fable is not currently offered as an advisor.

Use the executable launch profiles when you want a repeatable role route without editing shared settings:

```bash
/path/to/package/scripts/start-claude-route.sh everyday
/path/to/package/scripts/start-claude-route.sh planning
/path/to/package/scripts/start-claude-route.sh advisor
/path/to/package/scripts/start-claude-route.sh review
```

See [`docs/MODEL_ROUTING.md`](docs/MODEL_ROUTING.md) and [`docs/MODEL_ROUTE_PROFILES.md`](docs/MODEL_ROUTE_PROFILES.md).

## Authoritative orchestration

The 14 JavaScript workflow implementations are retired. Their capabilities remain available through
the eleven `madclaude` Python routes and four `repo-audit --profile` specializations. Python owns model
eligibility, Founder approval validation, mutation scope, verification, exact-SHA isolation, Tier-2
participant exclusion, evidence classification, and execution records.

See [`docs/DYNAMIC_WORKFLOWS.md`](docs/DYNAMIC_WORKFLOWS.md).

## Agent and skill registries

The 20 project agents cover exploration, dependency mapping, architecture, orchestration, one accountable implementation lane, worktree builds, root-cause diagnosis, testing, code/security/UI/performance review, governance, decision drafting, documentation, read-only Neon investigation, release verification, adversarial verification, exact-SHA Tier-2 review, and final synthesis.

The 31 skills keep large procedures out of the base context. The command router and palette expose the right procedure without requiring the Founder to remember every name.

See [`docs/SUBAGENT_REGISTRY.md`](docs/SUBAGENT_REGISTRY.md) and [`docs/COMMAND_PALETTE.md`](docs/COMMAND_PALETTE.md).

## Cloud and Remote Control

The package supports two distinct remote experiences:

- **Claude Code cloud** runs on Anthropic-managed infrastructure and should receive committed/pushed or bundled repository state plus a reviewed cloud environment.
- **Remote Control** leaves execution on the local machine and exposes the active local session through web/mobile. This is the correct route when local-only files, MCP servers, or approved local connectors must remain available.

Neither route grants new permissions or authority. See [`docs/CLOUD_ENVIRONMENT.md`](docs/CLOUD_ENVIRONMENT.md).

## Security boundaries

The full environment blocks or escalates:

- destructive Git/filesystem commands and force pushes;
- PR merge commands;
- access to common credential files;
- unapproved writes to constitutional, role-registry, decision-log, root instruction, and shared Claude-governance paths;
- mutating SQL in `neon-reader`;
- mutating shell or file tools in the exact-SHA independent reviewer.

Hooks are defense in depth. They do not replace GitHub branch protection, cloud IAM, database roles, secret management, organization policy, or human review. See [`docs/SECURITY_GOVERNANCE.md`](docs/SECURITY_GOVERNANCE.md).

## Package layout

```text
MADVentures-Claude-Code-Environment-v4.4.1/
├── README.md
├── START_HERE.md
├── CHANGELOG.md
├── VERSION
├── MANIFEST.json
├── SHA256SUMS.txt
├── cloud/
├── docs/
├── examples/
├── global/
├── plugin/
│   └── madventures-founderos/
├── python-control-plane/
├── project/
│   ├── .claude/
│   │   ├── FOUNDEROS.md
│   │   ├── MODEL_REGISTRY.md
│   │   ├── PROJECT_PROFILE.md
│   │   ├── agents/
│   │   ├── cloud/
│   │   ├── hooks/
│   │   ├── rules/
│   │   ├── skills/
│   │   ├── workflows/
│   │   └── settings.json
│   ├── profiles/
│   ├── .mcp.example.json
│   └── settings.local.example.json
└── scripts/
```

## Validate before deployment

```bash
python3 scripts/build-plugin.py
python3 scripts/validate-config.py
node scripts/validate-workflows.mjs
node scripts/test-hooks.mjs
bash scripts/smoke-test-install.sh
bash scripts/test-route-launcher.sh
bash scripts/test-cloud-session.sh
python3 python-control-plane/run-tests.py
python3 scripts/verify-release.py /path/to/full.zip /path/to/plugin.zip
```

Or build both validated release archives:

```bash
bash scripts/build-release.sh
```

The release pipeline writes:

- `MADVentures-Claude-Code-Environment-v4.4.1.zip` — universal full environment;
- `MADVentures-Claude-Code-Environment-v4.4.1.tar.gz` — macOS/Linux full environment with Unix permissions preserved;
- `MADVentures-FounderOS-Claude-Code-Plugin-v4.4.1.zip` — portable namespaced plugin.

Static validation proves package shape, syntax, references, guard placement, plugin adaptation, and installer behavior that can be exercised locally. It cannot prove account-specific model availability, organization policy, live MCP authentication, production access, or repository-specific commands.

## Lifecycle language

Treat these as distinct states:

`proposed`, `approved`, `implemented`, `verified`, `merged`, `deployed`, `activated`, `blocked`, `unknown`.

A missing source is not healthy. A merged PR is not deployed. A technical review is not Founder authorization.
